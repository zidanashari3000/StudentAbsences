/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

/**
 *
 * @author zidan
 */
import java.util.ArrayList;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.util.HibernateUtil;
import com.model.pojo.Absencesdata;

public class Dao {
     public void addAbsencesdata(Absencesdata absencesdata) {
        Session session
                = HibernateUtil.getSessionFactory().openSession();
        try {
            session.beginTransaction();
            session.merge(absencesdata);
            session.flush();
            session.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
            session.getTransaction().rollback();
        }

        session.close();
    }

      public void deleteAbsencesdata(int id)
    {
        Transaction trans=null;
        Session session=HibernateUtil.getSessionFactory().openSession();
        try 
        {
            trans=session.beginTransaction();
            Absencesdata data=(Absencesdata)session.load(Absencesdata.class, new Integer(id));
            session.delete(data);
            trans.commit();
        } 
        catch (Exception e) 
        {
            e.printStackTrace();
        }
    }
        
      public List<Absencesdata> getbyID(int sno)
    {
        Absencesdata data=new Absencesdata();
        List<Absencesdata> Absencesdata1=new ArrayList();
       
         Transaction trans=null;
        Session session=HibernateUtil.getSessionFactory().openSession();
        try 
        {
            trans=session.beginTransaction();
            Query query=session.createQuery("from Absencesdata where id= :id");
            query.setInteger("id", sno);
            data=(Absencesdata)query.uniqueResult();
            Absencesdata1=query.list();
            
            trans.commit();
        }
        catch(Exception e)
        {
            
        }
        return  Absencesdata1;
    }
      public List<Absencesdata> retrieveAbsencesdata()
    {
       
        List dat=new ArrayList();
        Absencesdata datta=new  Absencesdata ();
        Transaction trans=null;
        Session session=HibernateUtil.getSessionFactory().openSession();
        try
        {
            trans=session.beginTransaction();
            Query query=session.createQuery("from absencesdata");
            dat=query.list();
            dat.add(datta.getName());
            dat.add(datta.getDate());
            dat.add(datta.getTheory());
            
         
            trans.commit();
            
        }
        catch(Exception e)
        {
            
        }
        return dat;
    }
      public void updateAbsencesdata(Absencesdata absencesdata)
    {
        Transaction trans=null;
        Session session=HibernateUtil.getSessionFactory().openSession();
        try 
        {
            trans=session.beginTransaction();
            session.update(absencesdata);
            trans.commit();
        }
        catch(Exception e)
        {
            
        }
        
    }
    }
